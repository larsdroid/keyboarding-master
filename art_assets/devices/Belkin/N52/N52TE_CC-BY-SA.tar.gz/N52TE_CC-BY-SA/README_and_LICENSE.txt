Contained in this archive are top and side images of a gaming keyboard suitable for use in configuration applications. They were shot against a white background, cut out in the Gimp, and edited with the "heal brush" to remove most imperfections.

As you can see, the matte finish on the handrest has been worn off my unit. I also neglected to attach the thumbstick, but I hope these images are still helpful!

___

Gaming Keypad Refs by Nathan T is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.

http://creativecommons.org/licenses/by-sa/3.0/

Attribution for these images can be given to "Nathan T"
